#!/bin/bash
# Makes a backup of RAID configuration, partition tables 
# and logical volumes.

. lib/checkRoot.sh

checkRoot

# Saves data from RAID
mdadm --detail --scan --verbose > backed-up-files/RAID.conf


# Saves partitions specified in file files/disks.list 
exec < files/disks.list

while read line

	do
		newline="/dev/${line}" 
		dd  if=$newline of=backed-up-files/$line.mbr bs=512 count=1
		echo "Backed up device MBR from device ${newline} "
	done

# Saves logical volumes groups specified en file files/vgs.list

exec < files/vgs.list

while read line

	do
		newline="/dev/${line}" 
		vgcfgbackup -f backed-up-files/$line.vg $newline
	done




exit 0
