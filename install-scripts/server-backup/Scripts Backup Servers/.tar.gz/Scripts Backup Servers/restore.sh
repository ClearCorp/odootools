#!/bin/bash
#Restore Partition tables, RAID, and LVM'S previously backed up 



## Restore of partition tables from files "backed-up-files/sd*.mbr"

#for f in backed-up-files/sd*; do

#T=${f##*/}
#echo "${T}"
#echo "/dev/${T%.*}"

##dd  if=$f of=/dev/${T%.*} bs=512 count=1
partprobe

#done



# Parsing backed-up-files/RAID.conf so it has form of commands

cp backed-up-files/RAID.conf backed-up-files/RAID.conf.old
sed -i 's/ARRAY[[:space:]]*/mdadm create /g' backed-up-files/RAID.conf
sed -i 's/UUID=[[:alnum:]]*:[[:alnum:]]*:[[:alnum:]]*:[[:alnum:]]*/ /g' backed-up-files/RAID.conf
sed -i 's/[[:space:]]*level/ --level/g' backed-up-files/RAID.conf
sed -i 's/[[:space:]]*num/ --num/g' backed-up-files/RAID.conf
sed -i 's/[[:space:]]*spares/ --spares/g' backed-up-files/RAID.conf
sed -i 's/[[:space:]]*[[:space:]]devices/ --devices/g' backed-up-files/RAID.conf
cat backed-up-files/RAID.conf | tr '\n' ' ' > backed-up-files/RAID.conf
sed -i 's/mdadm/\nmdadm/g' backed-up-files/RAID.conf
sed '/^$/d' backed-up-files/RAID.conf > backed-up-files/RAID.conf.clean
echo  >>    backed-up-files/RAID.conf.clean
mv backed-up-files/RAID.conf.clean backed-up-files/RAID.conf


# Restores MD devices specified in backed-up-files/RAID.conf 

exec < backed-up-files/RAID.conf

while read line
	do
	echo "$line"
	done




# Restore logical volume groups from files "backed-up-files/*.vg"

for f in backed-up-files/*.vg; do

#T=${f##*/}
#echo "${T}"

vgcfgrestore -f ${f} ${T%.*}


done



exit 0
